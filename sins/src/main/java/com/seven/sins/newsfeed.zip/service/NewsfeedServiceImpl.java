package com.seven.sins.newsfeed.service;

public class NewsfeedServiceImpl {

}
