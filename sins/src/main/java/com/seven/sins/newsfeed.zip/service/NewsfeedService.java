package com.seven.sins.newsfeed.service;

public interface NewsfeedService {

}
