package com.seven.sins.newsfeed.vo;

public class NewsfeedVO {

}
