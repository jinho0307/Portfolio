package com.seven.sins.newsfeed.dao;

public class NewsfeedDAO {

}
